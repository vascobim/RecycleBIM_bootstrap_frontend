$(window).on('load', function(){
})